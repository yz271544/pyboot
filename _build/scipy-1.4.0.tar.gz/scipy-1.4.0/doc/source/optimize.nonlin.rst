.. automodule:: scipy.optimize.nonlin
   :no-members:
   :no-inherited-members:
   :no-special-members:
