:orphan:

.. _building:

Building from sources
=====================

.. note::

   If you are only trying to install SciPy, see
   :doc:`../install_upgrade`.

Build instructions for different operating systems and an FAQ:

.. toctree::
   :maxdepth: 2

   linux
   windows
   macosx
   faq
