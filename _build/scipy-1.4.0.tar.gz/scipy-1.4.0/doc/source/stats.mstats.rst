.. automodule:: scipy.stats.mstats
   :no-members:
   :no-inherited-members:
   :no-special-members:
