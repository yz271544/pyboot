.. _skip_list:

scikit-image proposals (SKIPS)
******************************

SKIPs document any major changes or proposals to the scikit-image project.

Sections
========

.. toctree::
   :maxdepth: 1

   0-skip-process
   1-governance
   2-values

.. toctree::
   :hidden:

   template

