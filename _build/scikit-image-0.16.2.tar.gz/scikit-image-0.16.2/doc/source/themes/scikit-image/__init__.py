def setup(app):
    app.add_js_file('searchtools.js')
