.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`external.tifffile`
================================
.. automodule:: skimage.external.tifffile

.. currentmodule:: skimage.external.tifffile
.. autosummary::

   skimage.external.tifffile.imsave
   skimage.external.tifffile.imread
   skimage.external.tifffile.imshow
   skimage.external.tifffile.parse_kwargs

   skimage.external.tifffile.TiffFile
   skimage.external.tifffile.TiffWriter
   skimage.external.tifffile.TiffSequence


imsave
------

.. autofunction:: skimage.external.tifffile.imsave


.. include:: skimage.external.tifffile.imsave.examples

imread
------

.. autofunction:: skimage.external.tifffile.imread


.. include:: skimage.external.tifffile.imread.examples

imshow
------

.. autofunction:: skimage.external.tifffile.imshow


.. include:: skimage.external.tifffile.imshow.examples

parse_kwargs
------------

.. autofunction:: skimage.external.tifffile.parse_kwargs


.. include:: skimage.external.tifffile.parse_kwargs.examples


:class:`TiffFile`
-----------------


.. autoclass:: TiffFile
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`TiffWriter`
-------------------


.. autoclass:: TiffWriter
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__

:class:`TiffSequence`
---------------------


.. autoclass:: TiffSequence
  :members:
  :undoc-members:
  :show-inheritance:

  .. automethod:: __init__
