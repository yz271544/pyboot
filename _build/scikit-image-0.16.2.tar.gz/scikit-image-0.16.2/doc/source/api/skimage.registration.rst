.. AUTO-GENERATED FILE -- DO NOT EDIT!

Module: :mod:`registration`
===========================
.. automodule:: skimage.registration

.. currentmodule:: skimage.registration
.. autosummary::

   skimage.registration.optical_flow_tvl1



optical_flow_tvl1
-----------------

.. autofunction:: skimage.registration.optical_flow_tvl1


.. include:: skimage.registration.optical_flow_tvl1.examples

